﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.MilitaryElite.Contracts
{
    public interface IMission
    {
        public string Name { get; }
        public string State { get;}
    }
}
