﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControl
{
    interface IBirthable
    {
        public string BirthDate { get; }
    }
}
