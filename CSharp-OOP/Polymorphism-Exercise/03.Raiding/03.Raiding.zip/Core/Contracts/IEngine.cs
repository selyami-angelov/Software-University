﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Raiding.Core.Contracts
{
    public interface IEngine
    {
        public void Run();
    }
}
