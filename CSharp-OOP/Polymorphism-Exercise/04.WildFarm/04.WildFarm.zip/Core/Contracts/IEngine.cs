﻿namespace _04.WildFarm.Core.Contracts
{
    public interface IEngine
    {
        public void Run();
    }
}
