﻿namespace Shapes
{
    interface IDrawable
    {
        public void Draw();
    }
}
