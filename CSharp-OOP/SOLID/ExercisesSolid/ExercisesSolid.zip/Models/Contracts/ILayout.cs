﻿

namespace ExercisesSolid.Models.Contracts
{
    public interface ILayout
    {
        public string Format { get;}
    }
}
