﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExercisesSolid.Core.Contracts
{
    public interface IEngine
    {
        public void Run();
    }
}
