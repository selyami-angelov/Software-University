﻿
namespace ExercisesSolid.Common
{
    public static class GlobalConstants
    {
        public static string DATE_FORMAT = "M/dd/yyyy h:mm:ss tt";
    }
}
