﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02.MultipleInheritance
{
    class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating…");
        }
    }
}
