﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02.MultipleInheritance
{
    class Cat
    {
        public void Meow()
        {
            Console.WriteLine("meowing…");
        }
    }
}
