﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02.MultipleInheritance
{
    class Puppy : Dog
    {
        public void Weep()
        {
            Console.WriteLine("weeping…");
        }
    }
}
