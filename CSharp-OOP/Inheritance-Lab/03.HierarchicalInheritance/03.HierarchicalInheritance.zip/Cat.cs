﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.HierarchicalInheritance
{
    public class Cat : Animal
    {
        public void Meow()
        {
            Console.WriteLine("meowing…");
        }
    }
}
