﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.SingleInheritance
{
    class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating…");
        }
    }
}
